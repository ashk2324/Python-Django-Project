from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import ToDoApp
from .forms import ToDoAppForm
# Create your views here.
def index(request):
    todo_list = ToDoApp.objects.all()

    form = ToDoAppForm()

    if request.method == "POST":
        form = ToDoAppForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('/')
    context = {'todoapp':todo_list, 'form':form}
    return render(request,'todo/page_list.html', context)

def update(request,pk):
    list = ToDoApp.objects.get(id=pk)

    form = ToDoAppForm(instance=list)

    if request.method == "POST":
        form = ToDoAppForm(request.POST,instance=list)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form':form}

    return render(request,'todo/page_update.html', context)

def delete(request,pk):
    item = ToDoApp.objects.get(id=pk)

    if request.method == "POST":
        item.delete()
        return redirect('/')

    context = {'item':item}
    return render(request, 'todo/page_delete.html', context)