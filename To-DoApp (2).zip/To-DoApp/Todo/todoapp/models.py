from django.db import models

# Create your models here.
class ToDoApp(models.Model):
    Enter_Todolist = models.CharField(max_length=100)
    Not_Complete = models.BooleanField(default=False)
    Complete = models.BooleanField(default=False)

def __str__(self):
    return self.Enter_Todolist